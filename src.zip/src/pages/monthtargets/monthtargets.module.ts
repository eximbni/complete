import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MonthtargetsPage } from './monthtargets';

@NgModule({
  declarations: [
    MonthtargetsPage,
  ],
  imports: [
    IonicPageModule.forChild(MonthtargetsPage),
  ],
})
export class MonthtargetsPageModule {}
