import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DisplaycountriesPage } from './displaycountries';

@NgModule({
  declarations: [
    DisplaycountriesPage,
  ],
  imports: [
    IonicPageModule.forChild(DisplaycountriesPage),
  ],
})
export class DisplaycountriesPageModule {}
